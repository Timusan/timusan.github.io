$(document).ready(function() {

    // Colorbox eye candy
    $('a.thumbnail').colorbox({
	rel:'thumbnail',
	scalePhotos:true,
	maxWidth:'95%',
	maxHeight:'95%',
	transition:'fade',
    });

});
